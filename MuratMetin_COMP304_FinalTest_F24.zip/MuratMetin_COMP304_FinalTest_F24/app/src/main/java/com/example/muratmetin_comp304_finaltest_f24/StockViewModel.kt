package com.murat.metin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class StockViewModel : ViewModel() {
    private val repository = StockRepository(AppDatabase.getDatabase(context = MyApplication.context).stockDao())

    private val _stockSymbols = MutableStateFlow<List<String>>(emptyList())
    val stockSymbols: StateFlow<List<String>> get() = _stockSymbols

    init {
        viewModelScope.launch {
            repository.allStockSymbols.collect {
                _stockSymbols.value = it
            }
        }
    }

    fun addStock(stockInfo: StockInfo) {
        viewModelScope.launch {
            repository.insertStock(stockInfo)
        }
    }
}
