package com.murat.metin

import kotlinx.coroutines.flow.Flow

class StockRepository(private val dao: StockDao) {
    val allStockSymbols: Flow<List<String>> = dao.getAllStockSymbols()

    suspend fun insertStock(stockInfo: StockInfo) {
        dao.insertStock(stockInfo)
    }

    suspend fun getStockDetails(symbol: String): StockInfo {
        return dao.getStockBySymbol(symbol)
    }
}
