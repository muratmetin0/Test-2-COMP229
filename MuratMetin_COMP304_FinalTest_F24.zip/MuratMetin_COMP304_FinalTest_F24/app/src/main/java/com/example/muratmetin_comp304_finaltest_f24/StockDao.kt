package com.murat.metin

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStock(stockInfo: StockInfo)

    @Query("SELECT stockSymbol FROM stock_info")
    fun getAllStockSymbols(): Flow<List<String>>

    @Query("SELECT * FROM stock_info WHERE stockSymbol = :symbol")
    suspend fun getStockBySymbol(symbol: String): StockInfo
}
