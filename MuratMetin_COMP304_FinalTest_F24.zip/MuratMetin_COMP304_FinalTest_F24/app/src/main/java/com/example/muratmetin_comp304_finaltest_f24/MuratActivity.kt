package com.murat.metin

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.murat.metin.ui.theme.MyApplicationTheme

class MuratActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                val viewModel: StockViewModel = viewModel()

                var stockSymbol by remember { mutableStateOf("") }
                var companyName by remember { mutableStateOf("") }
                var stockQuote by remember { mutableStateOf("") }

                Column(modifier = Modifier.padding(16.dp)) {
                    // Input Fields
                    TextField(
                        value = stockSymbol,
                        onValueChange = { stockSymbol = it },
                        label = { Text("Stock Symbol") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = companyName,
                        onValueChange = { companyName = it },
                        label = { Text("Company Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = stockQuote,
                        onValueChange = { stockQuote = it },
                        label = { Text("Stock Quote") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Add Button
                    Button(
                        onClick = {
                            viewModel.addStock(
                                StockInfo(
                                    stockSymbol = stockSymbol,
                                    companyName = companyName,
                                    stockQuote = stockQuote.toDouble()
                                )
                            )
                            stockSymbol = ""
                            companyName = ""
                            stockQuote = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add Stock")
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Stock Symbols List
                    LazyColumn {
                        items(viewModel.stockSymbols.collectAsState(initial = emptyList()).value) { symbol ->
                            Text(
                                text = symbol,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val intent = Intent(this@MuratActivity, DisplayActivity::class.java)
                                        intent.putExtra("stockSymbol", symbol)
                                        startActivity(intent)
                                    }
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
