package com.murat.metin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel

class DisplayActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: StockViewModel = viewModel()
            val stockSymbol = intent.getStringExtra("stockSymbol") ?: ""
            var stockDetails by remember { mutableStateOf<StockInfo?>(null) }

            LaunchedEffect(stockSymbol) {
                stockDetails = viewModel.getStockDetails(stockSymbol)
            }

            Column(modifier = Modifier.padding(16.dp)) {
                stockDetails?.let {
                    Text("Stock Symbol: ${it.stockSymbol}")
                    Text("Company Name: ${it.companyName}")
                    Text("Stock Quote: ${it.stockQuote}")
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { finish() }) {
                    Text("Back")
                }
            }
        }
    }
}
